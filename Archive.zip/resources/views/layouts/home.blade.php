@extends('layouts.master')
@section('content')

<div id="list-id" class="jumbotron">

	<div class="form-group form-group-lg">
	  <input class="form-control fuzzy-search uni-search" type="text" id="search" placeholder="Ricerca corso per nome o referenti.">
	</div><hr>
  <?php $courses = App\Course::All(); ?>
	@foreach($courses as $course)
	<ul class="list" style="list-style-type:none; padding:0px;">
    <li>
    <?php $c = 1; ?>
      @foreach($course->stripes as $stripe)
        <h3>Fascia {{$c}}</h3>
        <ul>
          @foreach($stripe->users as $user)
            <li>{{$user->name.$user->surname}}</li>
          @endforeach
        </ul>
        <?php $c = $c+1; ?>
      @endforeach
    </li>
	</ul>
	@endforeach
</div>

<script>

var fuzzyOptions = {
  searchClass: "fuzzy-search",
  location: 0,
  distance: 100,
  threshold: 0.4,
    multiSearch: true
};
var options = {
  valueNames: ['name','b_code','authors','price'],
  plugins: [
    ListFuzzySearch()
  ]
};

var listObj = new List('list-id', options);

</script>
@stop