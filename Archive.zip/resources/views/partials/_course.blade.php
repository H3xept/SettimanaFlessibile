<div class="panel panel-default">
  <div class="panel-heading table-layout:fixed;"> 
  <p class="lead" style="font-size:20px; margin-bottom:0px;">[Nuntius] Introduzione alla lingua giapponese.<span class="label label-default pull-right"> Progressivo </span></p> 
  </div>

  <div class="panel-body">
    <button class="btn btn-info">Info</button>
    <button class="btn btn-default">Iscriviti</button>

  </div>
</div>